/**
 * [YUI] Live Search
 * Initialise Script
 * Version 4.0.5
 * @author mad@Max
 */
(function(){var b=YAHOO.util;YAHOO.vBulletin.lsaobj=function(c,a){this.timeout=this.resobj=this.cont=this.req=null;this.textobj=b.Dom.get(c);this.textobj.value=vbphrase.live_search;this.textobj.setAttribute("autocomplete","off");this.min=3;b.Event.on(this.textobj,"focus",this.start,this,true);this.bb=location.href.search(/www\./)>-1?a.search(/www\./)<0?"http://www."+(a.substring(0,7)=="http://"?a.substring(7):a):a:a.search(/www\./)>-1?a.replace(/www\./,""):a};YAHOO.vBulletin.lsaobj.prototype.start= function(){this.textobj.value=vbphrase.lsa_loading;b.Get.script(["clientscript/yui/dragdrop/dragdrop-min.js","clientscript/ajax_live_search-min.js"],{onSuccess:function(){this.load()},scope:this})}})();